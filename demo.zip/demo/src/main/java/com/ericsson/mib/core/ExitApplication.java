package com.ericsson.mib.core;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ExitApplication {
	
	@Value("${alarm.purge.enabled}")
	private Boolean isAlarmPurgeEnabled;
	
	@Scheduled(cron = "0 0/2 * 2-30/2 * ?")
	public void shutdown() {
		if(isAlarmPurgeEnabled) {
			ConfigurableApplicationContext applicationContext = (ConfigurableApplicationContext) ApplicationContextManager.getApplicationContext();
			applicationContext.close();
		}
	}
}
