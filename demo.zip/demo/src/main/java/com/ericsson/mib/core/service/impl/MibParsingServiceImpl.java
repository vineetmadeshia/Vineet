package com.ericsson.mib.core.service.impl;

import com.ericsson.mib.core.service.MibParsingService;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class MibParsingServiceImpl implements MibParsingService {
  private static final Logger logger = LoggerFactory.getLogger(com.ericsson.mib.core.service.impl.MibParsingServiceImpl.class);
  
  Map<String, String> mibObjects = new HashMap<>();
  
  Map<String, String> oidsInMibs = new HashMap<>();
  
  Map<String, String> mibDependencies = new HashMap<>();
  
  Set<String> missingMibDependencies = new HashSet<>();
  
  public void loadMibs(String path) {
    List<File> files = new ArrayList<>();
    File mibFile = new File(path);
    fetchFiles(mibFile, files);
    try {
      FileWriter fWriter = new FileWriter("C:\\temp\\synapse.txt");
      readMibs(files);
      iterateMibs();
      logger.info("Final Mibs {}", this.oidsInMibs);
      this.oidsInMibs.forEach((k, v) -> {
            try {
              fWriter.append(k + "," + v + "\n");
            } catch (IOException e) {
              e.printStackTrace();
            } 
          });
      fWriter.close();
      logger.info("File written successfully.");
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
  
  private void fetchFiles(File mibFile, List<File> files) {
    for (File file : mibFile.listFiles()) {
      if (file.isDirectory()) {
        fetchFiles(file, files);
      } else {
        files.add(file);
        logger.info("Files {}", file.getName());
      } 
    } 
  }
  
  private void readMibs(List<File> files) throws IOException {
    for (File file : files) {
      String content = new String(Files.readAllBytes(Paths.get(file.getAbsolutePath(), new String[0])));
      logger.info("Reading File ------>" + file.getAbsolutePath());
      parseMibs(content);
    } 
  }
  
  private void parseMibs(String mibContent) {
    String metadataText = mibContent.substring(0, mibContent.indexOf(";"));
    String textToParse = mibContent.substring(mibContent.indexOf(";") + 1);
    readMibMetaData(metadataText);
    readMibData(textToParse);
  }
  
  private void readMibData(String textToParse) {
    textToParse = textToParse.replaceAll("--.*", "");
    Matcher matcherForInitialSplit = getMatcher(textToParse, "::=(\\s+|)\\{([^\\}]*)\\}", 8);
    while (matcherForInitialSplit.find()) {
      String group = matcherForInitialSplit.group(0);
      textToParse = textToParse.replace(group, group + "\n#######################");
    } 
    String[] mibContentArray = textToParse.split("#######################");
    for (String mibDetails : mibContentArray) {
      if (!mibDetails.trim().isEmpty()) {
        String oidKeyUsualText = null;
        Matcher matcher = getMatcher(mibDetails, "::=(\\s+|)\\{", 8);
        if (getMatcherCount(matcher).doubleValue() > 0.0D) {
          String[] mibArray = mibDetails.split("::=(\\s+|)\\{");
          Matcher identifierMatcher = getMatcher(mibDetails, "MODULE-IDENTITY|OBJECT-TYPE|NOTIFICATION-TYPE|NOTIFICATION-GROUP|OBJECT-GROUP|OBJECT_IDENTIFIER|OBJECT-IDENTITY|MODULE-COMPLIANCE|OBJECT IDENTIFIER", 8);
          if (getMatcherCount(identifierMatcher).doubleValue() > 0.0D) {
            String[] oidArr = mibArray[mibArray.length - 2].split("MODULE-IDENTITY|OBJECT-TYPE|NOTIFICATION-TYPE|NOTIFICATION-GROUP|OBJECT-GROUP|OBJECT_IDENTIFIER|OBJECT-IDENTITY|MODULE-COMPLIANCE|OBJECT IDENTIFIER");
            oidKeyUsualText = oidArr[0].trim();
          } else {
            String[] oidArr = mibArray[mibArray.length - 2].split("OBJECT IDENTIFIER");
            oidKeyUsualText = oidArr[0].trim();
          } 
          String[] splitByNewLine = oidKeyUsualText.split("\n");
          String oidKey = splitByNewLine[splitByNewLine.length - 1].trim();
          String[] oidValueArray = mibArray[mibArray.length - 1].split("\\}");
          String oidValue = oidValueArray[0].trim();
          this.mibObjects.put(oidKey, oidValue);
        } 
      } 
    } 
  }
  
  private void readMibMetaData(String metadataText) {
    if (metadataText.contains("IMPORTS")) {
      String[] mibMetaDataArr = metadataText.split("IMPORTS");
      String[] mibFileArr = mibMetaDataArr[mibMetaDataArr.length - 1].split("FROM");
      String[] splitImportsArr = mibFileArr[0].trim().split(",");
      String firstFileText = mibFileArr[1].split("\r\n|\n|\t")[0].trim();
      for (String modules : splitImportsArr)
        this.mibDependencies.put(modules.trim(), firstFileText); 
      for (int i = 2; i < mibFileArr.length; i++) {
        String[] metaDataPart = mibFileArr[i - 1].trim().split("\r\n|\n|\t");
        String[] metaDataPartNext = mibFileArr[i].trim().split("\r\n|\n|\t");
        for (int j = 1; j < metaDataPart.length; j++) {
          String[] moduleArr = metaDataPart[j].trim().split(",");
          for (String text : moduleArr)
            this.mibDependencies.put(text.trim(), metaDataPartNext[0].trim()); 
        } 
      } 
    } 
  }
  
  private void iterateMibs() {
    System.out.println("MibObjects : " + this.mibObjects);
    Set<Map.Entry<String, String>> entrySet = this.mibObjects.entrySet();
    for (Map.Entry<String, String> entry : entrySet) {
      try {
        String oidName = entry.getKey();
        String oidUnparsedValue = entry.getValue();
        parseValue(this.mibObjects, oidName, oidUnparsedValue);
      } catch (NullPointerException npe) {
        String message = npe.getMessage();
        this.missingMibDependencies.add(this.mibDependencies.get(message.split(":")[1].trim()));
        logger.error("Exception occured : {}", npe);
      } 
    } 
    logger.info("missingMibDependencies {}", this.missingMibDependencies);
  }
  
  private String parseValue(Map<String, String> mibObjects, String key, String oidUnparsedValue) throws NullPointerException {
    Matcher matcher = getMatcher(oidUnparsedValue, "\\(\\d+\\)", 8);
    if (getMatcherCount(matcher).doubleValue() > 0.0D) {
      String[] arrayOfString = oidUnparsedValue.split("\\s+");
      String middleText = "";
      for (String string : arrayOfString) {
        if (string.contains("(")) {
          String commaText = string.split("\\(")[1].split("\\)")[0];
          middleText = middleText + commaText + ".";
        } 
      } 
      logger.info("String --------->{}", arrayOfString[0] + "   " + middleText + arrayOfString[arrayOfString.length - 1]);
      if (arrayOfString[0].contains("(")) {
        oidUnparsedValue = middleText + arrayOfString[arrayOfString.length - 1];
      } else {
        oidUnparsedValue = arrayOfString[0] + "   " + middleText + arrayOfString[arrayOfString.length - 1];
      } 
    } 
    String[] oidUnparsedValueArr = oidUnparsedValue.split("\\s+");
    if (oidUnparsedValueArr.length > 1) {
      if (this.oidsInMibs.containsKey(oidUnparsedValueArr[0].trim())) {
        this.oidsInMibs.put(key.trim(), (String)this.oidsInMibs
            .get(oidUnparsedValueArr[0].trim()) + "." + oidUnparsedValueArr[1].trim());
      } else {
        String subValue = mibObjects.get(oidUnparsedValueArr[0].trim());
        if (subValue == null)
          throw new NullPointerException("MibObject not found : " + oidUnparsedValueArr[0].trim()); 
        parseValue(mibObjects, oidUnparsedValueArr[0].trim(), subValue);
      } 
    } else {
      this.oidsInMibs.put(key, oidUnparsedValueArr[0].trim());
    } 
    return oidUnparsedValueArr[0].trim();
  }
  
  public static Double getMatcherCount(Matcher matcher) {
    Double columnCount = Double.valueOf(0.0D);
    while (matcher.find())
      columnCount = Double.valueOf(columnCount.doubleValue() + 1.0D); 
    return columnCount;
  }
  
  public static Matcher getMatcher(String output, String pattern, int flags) {
    Pattern regexPattern = Pattern.compile(pattern, flags);
    Matcher matcher = regexPattern.matcher(output);
    return matcher;
  }
}
