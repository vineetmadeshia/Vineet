package com.ericsson.mib.core.trap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.snmp4j.mp.MPv3;
import org.snmp4j.security.SecurityProtocols;
import org.snmp4j.security.USM;
import org.snmp4j.smi.OctetString;

public class UsmFactory {
	
	private static final Logger logger = LoggerFactory.getLogger(UsmFactory.class);

	private static USM usm;

	private UsmFactory() {

	}

	public static USM getInstance() {
		/*
		 * if (usm == null) { synchronized (USM.class) { if (usm == null) {
		 * logger.info("USM instance creation initiated"); usm = new
		 * USM(SecurityProtocols.getInstance().addDefaultProtocols(), new
		 * OctetString(MPv3.createLocalEngineID()), 0); } } }
		 */
		usm = new USM(SecurityProtocols.getInstance().addDefaultProtocols(),
				new OctetString(MPv3.createLocalEngineID()), 0);
		usm.setEngineDiscoveryEnabled(true);
		logger.info("USM instance created : {}",usm);
		return usm;
	}
}
