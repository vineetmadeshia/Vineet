package com.ericsson.mib.core.trap.dto;

import java.math.BigInteger;
import java.util.Date;

public class TrapDefinition {
  private BigInteger id;
  
  private String oid;
  
  private String oidTitle;
  
  private String severity;
  
  private String trapDesc;
  
  private Date createdAt;
  
  private String createdBy;
  
  private Date updatedAt;
  
  private String updatedBy;
  
  public BigInteger getId() {
    return this.id;
  }
  
  public void setId(BigInteger id) {
    this.id = id;
  }
  
  public String getOid() {
    return this.oid;
  }
  
  public void setOid(String oid) {
    this.oid = oid;
  }
  
  public String getOidTitle() {
    return this.oidTitle;
  }
  
  public void setOidTitle(String oidTitle) {
    this.oidTitle = oidTitle;
  }
  
  public String getSeverity() {
    return this.severity;
  }
  
  public void setSeverity(String severity) {
    this.severity = severity;
  }
  
  public String getTrapDesc() {
    return this.trapDesc;
  }
  
  public void setTrapDesc(String trapDesc) {
    this.trapDesc = trapDesc;
  }
  
  public Date getCreatedAt() {
    return this.createdAt;
  }
  
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }
  
  public String getCreatedBy() {
    return this.createdBy;
  }
  
  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }
  
  public Date getUpdatedAt() {
    return this.updatedAt;
  }
  
  public void setUpdatedAt(Date updatedAt) {
    this.updatedAt = updatedAt;
  }
  
  public String getUpdatedBy() {
    return this.updatedBy;
  }
  
  public void setUpdatedBy(String updatedBy) {
    this.updatedBy = updatedBy;
  }
  
  public boolean equals(Object obj) {
    if (obj == this)
      return true; 
    if (obj == null || obj.getClass() != getClass())
      return false; 
    com.ericsson.mib.core.trap.dto.TrapDefinition p = (com.ericsson.mib.core.trap.dto.TrapDefinition)obj;
    if (getOid().equals(p.getOid()))
      return true; 
    return false;
  }
}
