package com.ericsson.mib.core.common.util;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StringUtil {
  public static boolean isNumeric(String text) {
    Matcher matcher = getMatcher(text.trim(), "^[-+]?\\d*\\.?\\d*$", 8);
    return matcher.matches();
  }
  
  public static Matcher getMatcher(String output, String pattern, int flags) {
    Pattern regexPattern = Pattern.compile(pattern, flags);
    Matcher matcher = regexPattern.matcher(output);
    return matcher;
  }
  
  public static List<String> GetListWithDelimiter(String value, String string) {
    return (List<String>)Stream.<String>of(value.split(string)).collect(Collectors.toList());
  }
}
