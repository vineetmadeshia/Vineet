package com.ericsson.mib.core.mapper;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.stereotype.Component;

@Component
public class GenericServiceMapper extends AbstractServiceMapper {
  private ModelMapper modelMapper;
  
  public GenericServiceMapper() {
    this.modelMapper = new ModelMapper();
    this.modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
  }
  
  public <D, T> D mapEntityToDto(T entity, Class<D> dto) {
    return (D)this.modelMapper.map(entity, dto);
  }
  
  public <T, D> T mapDtoToEntity(D dto, Class<T> entity) {
    return (T)this.modelMapper.map(dto, entity);
  }
  
  public <D, T> List<D> mapEntityListToDtoList(Collection<T> entityList, Class<D> dto) {
    return (List<D>)entityList.stream().map(entity -> map(entity, dto)).collect(Collectors.toList());
  }
  
  public <T, D> List<T> mapDtoListToEntityList(Collection<D> dtoList, Class<T> entity) {
    return (List<T>)dtoList.stream().map(dto -> map(dto, entity)).collect(Collectors.toList());
  }
  
  protected ModelMapper getModelMapper() {
    return this.modelMapper;
  }
  
  protected void setModelMapper(ModelMapper modelMapper) {
    this.modelMapper = modelMapper;
  }
}
