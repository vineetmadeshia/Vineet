package com.ericsson.mib.core.trap.dto;

import com.ericsson.mib.core.trap.dto.VariableMap;

public class EsaVariableBinding {
  private VariableMap sysUpTime;
  
  private VariableMap alarmModelDescription;
  
  private VariableMap alarmResourceId;
  
  private VariableMap alarmActiveDescription;
  
  private VariableMap eventType;
  
  private VariableMap probableCause;
  
  private VariableMap moduleId;
  
  private VariableMap errorCode;
  
  private VariableMap severity;
  
  private VariableMap originatingSource;
  
  public VariableMap getSysUpTime() {
    return this.sysUpTime;
  }
  
  public void setSysUpTime(VariableMap sysUpTime) {
    this.sysUpTime = sysUpTime;
  }
  
  public VariableMap getAlarmModelDescription() {
    return this.alarmModelDescription;
  }
  
  public void setAlarmModelDescription(VariableMap alarmModelDescription) {
    this.alarmModelDescription = alarmModelDescription;
  }
  
  public VariableMap getAlarmResourceId() {
    return this.alarmResourceId;
  }
  
  public void setAlarmResourceId(VariableMap alarmResourceId) {
    this.alarmResourceId = alarmResourceId;
  }
  
  public VariableMap getEventType() {
    return this.eventType;
  }
  
  public void setEventType(VariableMap eventType) {
    this.eventType = eventType;
  }
  
  public VariableMap getProbableCause() {
    return this.probableCause;
  }
  
  public void setProbableCause(VariableMap probableCause) {
    this.probableCause = probableCause;
  }
  
  public VariableMap getModuleId() {
    return this.moduleId;
  }
  
  public void setModuleId(VariableMap moduleId) {
    this.moduleId = moduleId;
  }
  
  public VariableMap getErrorCode() {
    return this.errorCode;
  }
  
  public void setErrorCode(VariableMap errorCode) {
    this.errorCode = errorCode;
  }
  
  public VariableMap getSeverity() {
    return this.severity;
  }
  
  public void setSeverity(VariableMap severity) {
    this.severity = severity;
  }
  
  public VariableMap getOriginatingSource() {
    return this.originatingSource;
  }
  
  public void setOriginatingSource(VariableMap originatingSource) {
    this.originatingSource = originatingSource;
  }
  
  public VariableMap getAlarmActiveDescription() {
    return this.alarmActiveDescription;
  }
  
  public void setAlarmActiveDescription(VariableMap alarmActiveDescription) {
    this.alarmActiveDescription = alarmActiveDescription;
  }
}
