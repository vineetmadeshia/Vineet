package com.ericsson.mib.core.mapper;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JsonMapperUtil {
  private static final Logger logger = LoggerFactory.getLogger(com.ericsson.mib.core.mapper.JsonMapperUtil.class);
  
  public static <T> Object convertJsonToObject(String content, Class<T> classType) {
    try {
      ObjectMapper mapper = new ObjectMapper();
      return mapper.readValue(content, classType);
    } catch (JsonParseException e) {
      logger.error("Exception | JsonMapperUtil : " + e.getMessage());
    } catch (JsonMappingException e) {
      logger.error("Exception | JsonMapperUtil : " + e.getMessage());
    } catch (IOException e) {
      logger.error("Exception | JsonMapperUtil : " + e.getMessage());
    } 
    return null;
  }
  
  public static <T> Map<String, T> convertJsonToObject(String content) {
    try {
      ObjectMapper mapper = new ObjectMapper();
      return (Map<String, T>)mapper.readerFor((TypeReference)new Object())
        .readValue(content);
    } catch (JsonParseException e) {
      logger.error("Exception | JsonMapperUtil : " + e.getMessage());
    } catch (JsonMappingException e) {
      logger.error("Exception | JsonMapperUtil : " + e.getMessage());
    } catch (IOException e) {
      logger.error("Exception | JsonMapperUtil : " + e.getMessage());
    } 
    return null;
  }
  
  public static String convertObjectToJson(Object object) {
    try {
      ObjectMapper mapper = new ObjectMapper();
      return mapper.writeValueAsString(object);
    } catch (JsonMappingException e) {
      System.out.println("Error | convertObjectToJson=" + e);
      logger.error("Exception | JsonMapperUtil : " + e.getMessage());
    } catch (JsonProcessingException e) {
      System.out.println("Error | convertObjectToJson=" + e);
      logger.error("Exception | JsonMapperUtil : " + e.getMessage());
    } 
    return null;
  }
  
  public static Map<?, ?> convertObjectToMap(Object object) {
    ObjectMapper mapper = new ObjectMapper();
    return (Map<?, ?>)mapper.convertValue(object, Map.class);
  }
}
