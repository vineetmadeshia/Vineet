package com.ericsson.mib.core.trap.dto;

import java.util.Arrays;
import org.snmp4j.smi.VariableBinding;

public class TrapInfo {
  String ip;
  
  VariableBinding[] variableBinding;
  
  public String toString() {
    return "TrapInfo(ip=" + getIp() + ", variableBinding=" + Arrays.deepToString((Object[])getVariableBinding()) + ")";
  }
  
  public String getIp() {
    return this.ip;
  }
  
  public void setIp(String ip) {
    this.ip = ip;
  }
  
  public VariableBinding[] getVariableBinding() {
    return this.variableBinding;
  }
  
  public void setVariableBinding(VariableBinding[] variableBinding) {
    this.variableBinding = variableBinding;
  }
}
