package com.ericsson.mib.core.trap;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.snmp4j.MessageDispatcher;
import org.snmp4j.MessageDispatcherImpl;
import org.snmp4j.Snmp;
import org.snmp4j.mp.MPv1;
import org.snmp4j.mp.MPv2c;
import org.snmp4j.mp.MPv3;
import org.snmp4j.security.Priv3DES;
import org.snmp4j.security.SecurityProtocols;
import org.snmp4j.security.USM;
import org.snmp4j.security.UsmUser;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.GenericAddress;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.TcpAddress;
import org.snmp4j.smi.TransportIpAddress;
import org.snmp4j.smi.UdpAddress;
import org.snmp4j.transport.AbstractTransportMapping;
import org.snmp4j.transport.DefaultTcpTransportMapping;
import org.snmp4j.transport.DefaultUdpTransportMapping;
import org.snmp4j.util.MultiThreadedMessageDispatcher;
import org.snmp4j.util.ThreadPool;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Component;

import com.ericsson.mib.core.ApplicationContextManager;


@Component
@DependsOn("trap-ssh-ext-executor")
public class TrapAgent {

	Logger _logger = LoggerFactory.getLogger("traps");

	public static final String EXECUTOR_POOL_TRAP = "trap-ssh-ext-executor";

	@Autowired
	TrapCommandResponder trapCommandResponder;

	private AbstractTransportMapping<?> transport;

	/**
	 * This method will listen for traps and response pdu's from SNMP agent.
	 */
	public synchronized void listen(TransportIpAddress address)
			throws IOException {
		AbstractTransportMapping<?> transport = getTransportMapping(address);
		setSnmpParameters(transport);
		_logger.info("Trap Receiver service started");
		try {
			this.wait();
		} catch (InterruptedException ex) {
			_logger.error("Thread interrupted, failed to start trap service..");
			Thread.currentThread().interrupt();
		}
	}

	private void setSnmpParameters(AbstractTransportMapping<?> transport)
			throws IOException {
		_logger.info("going to set Snmp parameters");
		ThreadPool threadPool = (ThreadPool) ApplicationContextManager.getBean(EXECUTOR_POOL_TRAP, ThreadPool.class);
		MessageDispatcher mtDispatcher = getDispatcher(threadPool);

		// add all security protocols
		// SecurityProtocols.getInstance().addDefaultProtocols();
		// SecurityProtocols.getInstance().addPrivacyProtocol(new Priv3DES());
		
		Snmp snmp = SnmpFactory.getInstance();
		snmp.setMessageDispatcher(mtDispatcher);
		snmp.addTransportMapping(transport);
		snmp.addCommandResponder(trapCommandResponder);
		snmp.listen();
		USM usm = snmp.getUSM();
		addUser(snmp, usm);

		/*
		 * usm.addUser( new OctetString("mio5v3"), new UsmUser(new
		 * OctetString("mio5v3"), AuthMD5.ID, new OctetString("Z4ZXGWl8EdQnB"),
		 * PrivAES128.ID, new OctetString("Z4ZXGWl8EdQnB")));
		 */
	}

	private void addUser(Snmp snmp, USM usm) {
		_logger.info("going to create USM");
			try {
				int port = 161;
				_logger.info("nodeIp : is : {} and port is :{}", node.getNodeIp(), port);
				Address address = GenericAddress
						.parse(String.format("udp:%s/%s", node.getNodeIp(), port == 0 ? 161 : port));
				byte[] engineId = snmp.discoverAuthoritativeEngineID(address, 5000);
				_logger.info("Engine Id for nodeIp : {} is : {} ", address, engineId);
				usm.addUser(new OctetString(nodeSnmpConfig.getSnmpUser()), new OctetString(engineId),
						new UsmUser(new OctetString(nodeSnmpConfig.getSnmpUser()),
								(nodeSnmpConfig.getAuthenticationType() != null)
										? SnmpAuthType.valueOf(nodeSnmpConfig.getAuthenticationType()).getOID()
										: null,
								new OctetString(nodeSnmpConfig.getSnmpPassword()),
								(nodeSnmpConfig.getEncryptionType() != null)
										? PrivProtType.valueOf(nodeSnmpConfig.getEncryptionType()).getOID()
										: null,
								(nodeSnmpConfig.getEncryptionKey() != null)
										? new OctetString(nodeSnmpConfig.getEncryptionKey())
										: null));
			} catch (Exception e) {
				_logger.error("Error while adding user for node : {}, check snmp configuration : {} ",e);
			}
	}

	private MessageDispatcher getDispatcher(ThreadPool threadPool) {
		USM usm = UsmFactory.getInstance();
		SecurityProtocols.getInstance().addPrivacyProtocol(new Priv3DES());
		// usm.setEngineDiscoveryEnabled(true);
		MessageDispatcher mtDispatcher = new MultiThreadedMessageDispatcher(threadPool, new MessageDispatcherImpl());

		// add message processing models
		mtDispatcher.addMessageProcessingModel(new MPv1());
		mtDispatcher.addMessageProcessingModel(new MPv2c());
		mtDispatcher.addMessageProcessingModel(new MPv3(usm));
		return mtDispatcher;
	}

	private AbstractTransportMapping<?> getTransportMapping(TransportIpAddress address) throws IOException {
		AbstractTransportMapping<?> transport;
		if (address instanceof TcpAddress) {
			transport = new DefaultTcpTransportMapping((TcpAddress) address);
		} else {
			transport = new DefaultUdpTransportMapping((UdpAddress) address);
		}
		this.transport = transport;
		return transport;
	}

	public void close() throws IOException {
		this.transport.close();
	}
}