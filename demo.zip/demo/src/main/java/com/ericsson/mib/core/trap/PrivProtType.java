package com.ericsson.mib.core.trap;

import org.snmp4j.smi.OID;

public enum PrivProtType {
	
	PrivAES128("PrivAES128") {
		@Override
		public OID getOID() {
			return org.snmp4j.security.PrivAES128.ID;
		}
	},
	Priv3DES("Priv3DES") {
		@Override
		public OID getOID() {
			return org.snmp4j.security.Priv3DES.ID;
		}
	},
	PrivAES192("PrivAES192") {
		@Override
		public OID getOID() {
			return org.snmp4j.security.PrivAES192.ID;
		}
	},
	PrivAES256("PrivAES256") {
		@Override
		public OID getOID() {
			return org.snmp4j.security.PrivAES256.ID;
		}
	};
	
	String type;
	
	private PrivProtType(String type){
		this.type = type; 
	}
	
	public abstract OID getOID();
}
