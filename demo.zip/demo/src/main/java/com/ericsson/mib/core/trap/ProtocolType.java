package com.ericsson.mib.core.trap;


public enum ProtocolType {
	
	SSH(1), SFTP(2),TELNET(3),SNMP(4);
	
	private final Integer protocolTypeId;
	
	private ProtocolType(Integer protocolTypeId){
		this.protocolTypeId = protocolTypeId; 
	}
	
	public Integer getProtocolTypeId() {
		return protocolTypeId;
	}

	public static ProtocolType getProtocolEnum(Integer protocolTypeId)
	{
		for (ProtocolType protocolType : ProtocolType.values())
		{
			if (protocolType.getProtocolTypeId().equals(protocolTypeId))
			{
				return protocolType;
			}
		}
		return null;
	}
}
