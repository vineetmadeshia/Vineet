package com.ericsson.mib.core.trap;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.snmp4j.smi.UdpAddress;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ericsson.mib.core.service.TrapReceiverService;

@Service
public class TrapReceiverServiceImpl implements TrapReceiverService {

	Logger _logger = LoggerFactory.getLogger("traps");

	@Value("${snmp.trap.listener.enabled}")
	private Boolean isTrapListenerEnabled;

	@Value("${snmp.manager.machine.ip}")
	private String managerIp;

	@Value("${snmp.manager.machine.port}")
	private String managerPort;

	@Autowired
	TrapAgent agent;

	@PostConstruct
	@Override
	public void startListener() {
		if (isTrapListenerEnabled) {
			new Thread(new Runnable() {
				@Override
				public void run() {
					listen();
				}
			}).start();
		} else {
			_logger.info("START_TRAP_LISTENER_SERVICE :: " + isTrapListenerEnabled);
		}
	}

	private void listen() {
		String udpAddress = managerIp + "/" + managerPort;
		UdpAddress address = new UdpAddress(udpAddress);
		try {
			_logger.info(String.format("Starting Trap Receiver service on %s:%s", managerIp, managerPort));
			agent.listen(address);
		} catch (IOException e) {
			_logger.error("Error starting Trap Receiver service :: ", e);
		}
		_logger.info("Listening on " + address);
	}

	@Override 
	public void close() {
		try {
			agent.close();
			_logger.info("Trap Agent successfully closed.");
		} catch (IOException e) {
			_logger.error("Error occurred while closing trap transport : {}", e);
		}
	}
}
