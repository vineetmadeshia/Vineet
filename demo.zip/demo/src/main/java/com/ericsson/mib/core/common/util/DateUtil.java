package com.ericsson.mib.core.common.util;

import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

//import org.joda.time.DateTime;
//import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.ericsson.mib.core.common.constants.Constants;

public class DateUtil {

	private static final Logger logger = LoggerFactory.getLogger(DateUtil.class);

	public static Date now() {
		return Calendar.getInstance().getTime();
	}

	public static Calendar currentDate() {
		return Calendar.getInstance();
	}

	public static int getYear() {
		return currentDate().get(Calendar.YEAR);
	}

	public static Date getDate(String input, String formatter) {
		try {
			if (!StringUtils.isEmpty(input)) {
				Date date = new SimpleDateFormat(formatter).parse(input);
				// logger.debug("getDate : input: {}| output Date: {}", input, date);
				return date;
			}
			return null;
		} catch (ParseException e) {
			logger.error("Failed to parse date: " + input + " with formatter: {}", formatter, e);
		}
		return null;
	}

	public static String toString(Date obj, String formatter) {
		if (obj == null) {
			return "";
		}
		DateFormat fmt = new SimpleDateFormat(formatter);
		return fmt.format(obj);
	}

	public static String toString(Date obj, String formatter, String timezone) {
		if (obj == null) {
			return "";
		}
		DateFormat fmt = new SimpleDateFormat(formatter);
		TimeZone tz = TimeZone.getTimeZone(timezone);
		fmt.setTimeZone(tz);
		return fmt.format(obj);
	}

	public static String toString(String input, String inputFormatter, String requriedFormatter) {
		if (input == null) {
			return "";
		}
		Date timestampObj = DateUtil.getDate(input, inputFormatter);
		return DateUtil.toString(timestampObj, requriedFormatter);
	}

	public static Calendar dateToCalendar(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return calendar;
	}

	public static Date calendarToDate(Calendar calendar) {
		return calendar.getTime();
	}

	public static Date getBackDate(Date date, int backDayCount) {
		Calendar cal = dateToCalendar(date);
		cal.add(Calendar.DATE, -backDayCount);
		return calendarToDate(cal);
	}

	public static Date alterDateByHour(Date timestamp, Integer hourCount) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(timestamp);
		Integer hour = cal.get(Calendar.HOUR_OF_DAY) + hourCount;
		cal.set(Calendar.HOUR_OF_DAY, hour);
		return cal.getTime();
	}

	public static Date decreaseDateByHour(Date timestamp, Integer hour) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(timestamp);
		cal.add(Calendar.HOUR, -hour);
		return cal.getTime();
	}

	public static Date decreaseDateByMin(Date timestamp, Integer min) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(timestamp);
		cal.add(Calendar.MINUTE, -min);
		return cal.getTime();
	}

	public static Date decreaseDateByDays(Date timestamp, Integer days) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(timestamp);
		cal.add(Calendar.DATE, (-1) * days);
		return cal.getTime();
	}

	/*
	 * public static Date converDateToTimezone(Date date, String timeZone) {
	 * TimeZone tz = TimeZone.getDefault(); logger.info("default timezone :"+tz);
	 * DateTimeZone dtZone = DateTimeZone.forID(timeZone); DateTime dt = new
	 * DateTime(date); DateTime dtWithTimeZone = dt.withZone(dtZone); Date
	 * dateInTimeZone = dtWithTimeZone.toLocalDateTime().toDate(); return
	 * dateInTimeZone; }
	 */

	public static Date truncateHour(Date input) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(input);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		return cal.getTime();
	}

	public static Date addMinute(Date input, Integer minute) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(input);
		cal.add(Calendar.MINUTE, minute);
		return cal.getTime();
	}

	public static Date addHour(Date input, int hour) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(input);
		cal.add(Calendar.HOUR, hour);
		return cal.getTime();
	}

	/*
	 * public static String getHourlyReportTimestamp(String applicationTimestamp,
	 * Date input) { if (input == null) { input = now(); } input =
	 * converDateToTimezone(input, applicationTimestamp); return
	 * getHourlyReportTimestamp(input); }
	 */

	public static String getHourlyReportTimestamp(Date input) {
		if (input == null) {
			input = now();
		}
		// truncate minute and second part
		Calendar cal = Calendar.getInstance();
		cal.setTime(input);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		// set to one hour back
		Integer hour = cal.get(Calendar.HOUR_OF_DAY) - 1;
		cal.set(Calendar.HOUR_OF_DAY, hour);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		return toString(cal.getTime(), "dd_MMM_yyyy_HH");
	}

	/*
	 * public static Date converDateToTimezone(Date date, String timeZone) {
	 * TimeZone tz = TimeZone.getDefault(); // logger.info("default timezone :"+tz);
	 * DateTimeZone dtZone = DateTimeZone.forID(timeZone); DateTime dt = new
	 * DateTime(date); DateTime dtWithTimeZone = dt.withZone(dtZone); Date
	 * dateInTimeZone = dtWithTimeZone.toLocalDateTime().toDate(); return
	 * dateInTimeZone; }
	 */

	public static String getDateString(Date input) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(input);
		return toString(cal.getTime(), "yyyy-MM-dd");
	}

	public static String getTimeString(Date input) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(input);
		return toString(cal.getTime(), "HHmm");
	}

	public static Double toSeconds(Long value) {
		value = value == null ? 0 : value;
		Double millisTosecs = millisTosecs(value);
		Double decimalPlaces = toDecimalPlaces(millisTosecs);
		return decimalPlaces;
	}

	public static Double millisTosecs(Long value) {
		value = value == null ? 0 : value;
		Double doubleValue = value.doubleValue() / 1000;
		return doubleValue;
	}

	public static Double millisToMins(Long value) {
		value = value == null ? 0 : value;
		Double doubleValue = value.doubleValue() / (1000 * 60);
		return doubleValue;
	}

	public static Double millisToHrs(Long value) {
		value = value == null ? 0 : value;
		Double doubleValue = value.doubleValue() / (1000 * 60 * 60);
		return doubleValue;
	}

	public static Double toDecimalPlaces(Double value) {
		value = value == null ? 0 : value;
		DecimalFormat df = new DecimalFormat(Constants.DECIMAL_FORMAT);
		df.setRoundingMode(RoundingMode.HALF_UP);
		return Double.valueOf(df.format(value));
	}

	public synchronized static Calendar roundToMinutes(Calendar calendar, Integer floorOffSet) {
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);

		int modulo = calendar.get(Calendar.MINUTE) % floorOffSet;
		if (modulo > 0) {
			calendar.add(Calendar.MINUTE, -modulo);
		}
		return calendar;
	}

	public synchronized static Calendar substractMinutesAfterTruncate(Calendar calendar, Integer subMinutes,
			Integer floorOffSet) {
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		Calendar cal = roundToMinutes(calendar, floorOffSet);
		cal.add(Calendar.MINUTE, -subMinutes);
		return cal;
	}

	public synchronized static Calendar roundToHour(Calendar calendar) {
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar;
	}

	public synchronized static Calendar substractHoursAfterTruncate(Calendar calendar, Integer subtractHours) {
		Calendar calendarInstance = Calendar.getInstance();
		calendarInstance.setTimeInMillis(calendar.getTimeInMillis());
		calendarInstance.set(Calendar.MINUTE, 0);
		calendarInstance.set(Calendar.SECOND, 0);
		calendarInstance.set(Calendar.MILLISECOND, 0);
		calendarInstance.add(Calendar.HOUR, -subtractHours);
		return calendarInstance;
	}

	public synchronized static String getNDaysBackDate(Integer days, String dateFormat) {
		LocalDate localDate = LocalDate.now().minusDays(Long.valueOf(days));
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateFormat);
		return localDate.format(formatter);
	}

	public synchronized static Date getTruncatedCurrentDate() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
	}

	public static String convertIsoToDateString(String isoDate, String returnFormatter) {
		try {
			String date = new SimpleDateFormat(returnFormatter)
					.format(Date.from(ZonedDateTime.parse(isoDate).toInstant()));
			logger.info("convertIsoToDateString : isoString={} | | converted={}", isoDate, date);
			return date;
		} catch (Exception e) {
			logger.error(
					"Error : convertIsoToDateString | unable to parse iso date to date | input.isoString=" + isoDate,
					e);
		}
		return null;
	}

	public static String toRfcFormat(String input, String inputFormatter) {
		try {
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
			dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
			return dateFormat.format(new SimpleDateFormat(inputFormatter).parse(input));
		} catch (ParseException e) {
			logger.error("Error:unable to convert toRfcFormat | input={} | inputFormatter={}", input, inputFormatter,
					e);
		}
		return null;
	}

	public static String toRfcFormat(Date input) {
		try {
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
			dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
			return dateFormat.format(input);
		} catch (Exception e) {
			logger.error("Error:unable to convert toRfcFormat | input={} ", input, e);
		}
		return null;
	}

	public static String rfcToSimpleDateFormat(String input) {
		try {
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
			dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			return format.format(dateFormat.parse(input));
		} catch (Exception e) {
			logger.error("Error:unable to convert toRfcFormat | input={} ", input, e);
		}
		return null;
	}
	
	public static String subMinutesFromDate(String date,Integer minutes,String format) {
		
		return "";
	}
}