package com.ericsson.mib.core.trap;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.snmp4j.smi.VariableBinding;

import com.ericsson.mib.core.trap.dto.EsaVariableBinding;
import com.ericsson.mib.core.trap.dto.TrapDefinition;
import com.ericsson.mib.core.trap.dto.TrapInfo;
import com.ericsson.mib.core.trap.dto.VariableMap;

public class TrapProcessor {
	private static final Logger logger = LoggerFactory.getLogger("traps");

	private final static String oidKey = "1.3.6.1.6.3.1.1.4.1.0";

	public static String getTrapDefinitionKey(VariableBinding[] variableBindings) throws ParseException {
		String trapDefinitionKey = null;
		for (VariableBinding variableBinding : variableBindings) {
			String oid = variableBinding.getOid().toString();
			if (oid.equalsIgnoreCase(oidKey)) {
				trapDefinitionKey = variableBinding.toValueString();
				break;
			}
		}
		return trapDefinitionKey;
	}

	public static String trapInfo(String trapKeyVal) {
		try {
			String value = "";
			if (trapKeyVal.trim().contains("=")) {
				String[] tempKeyVal = trapKeyVal.split("=");
				value = tempKeyVal[1].trim();
			}
			return value;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return "Problem while fetching";
		}
	}

	public static String getPeerAddress(String peerAddress) {
		try {
			if (peerAddress.contains("/")) {
				String[] ipPort = peerAddress.split("/");
				peerAddress = ipPort[0];
			}
		} catch (Exception e) {
			logger.error("Error occurred while parsing ip and port ", e);
		}
		return peerAddress;
	}

	public static String getParsedDescription(TrapInfo trap, List<TrapDefinition> definitions,
			EsaVariableBinding esaVariableBinding) {
		StringBuilder builder = new StringBuilder();
		VariableBinding[] variableBindings = trap.getVariableBinding();
		Map<String, String> trapMap = new HashMap<>();
		try {
			trapMap = definitions.stream()
					.collect(Collectors.toMap(TrapDefinition::getOid, TrapDefinition::getOidTitle));
		} catch (Exception e) {

		}

		for (VariableBinding variableBinding : variableBindings) {
			for (TrapDefinition definition : definitions) {
				String oid = variableBinding.getOid().toString();
				if (oid.concat(".").contains(definition.getOid().concat("."))) {
					buildOid(esaVariableBinding, builder, variableBinding, definition, trapMap);
				} else if (oid.substring(0, oid.lastIndexOf(".")).concat(".")
						.contains(definition.getOid().concat("."))) {
					buildOid(esaVariableBinding, builder, variableBinding, definition, trapMap);
				}
			}
		}
		return builder.toString();

	}

	private static void buildOid(EsaVariableBinding esaVariableBinding, StringBuilder builder,
			VariableBinding variableBinding, TrapDefinition definition, Map<String, String> trapMap) {
		String oidConfDef = definition.getOidTitle();
		String valueString = trapMap.get(variableBinding.toValueString()) == null ? variableBinding.toValueString()
				: trapMap.get(variableBinding.toValueString());
		builder.append(oidConfDef).append(" : ").append(valueString).append("\n");
		setVariableMap(oidConfDef, valueString, esaVariableBinding);
	}

	public static String getParsedOid(TrapInfo trap, TrapDefinition definition) {
		VariableBinding[] variableBindings = trap.getVariableBinding();
		for (VariableBinding variableBinding : variableBindings) {
			if (variableBinding.getOid().toString().contains(definition.getOid())) {
				return variableBinding.toValueString();
			}
		}

		return null;
	}

	private static void setVariableMap(String oidConfDef, String defValue, EsaVariableBinding esaVariableBinding) {
		if (oidConfDef.matches(".*ModelDescription.*|.*SpecificProblem.*")) {
			esaVariableBinding.setAlarmModelDescription(new VariableMap(oidConfDef, defValue));
		} else if (oidConfDef.contains("ResourceId")) {
			esaVariableBinding.setAlarmResourceId(new VariableMap(oidConfDef, defValue));
		} else if (oidConfDef.contains("ActiveDescription")) {
			esaVariableBinding.setAlarmActiveDescription(new VariableMap(oidConfDef, defValue));
		} else if (oidConfDef.matches(".*EventType.*")) {
			esaVariableBinding.setEventType(new VariableMap(oidConfDef, defValue));
		} else if (oidConfDef.contains("ProbableCause|.*AdditionalText.*")) {
			esaVariableBinding.setProbableCause(new VariableMap(oidConfDef, defValue));
		} else if (oidConfDef.contains("ModuleId")) {
			esaVariableBinding.setModuleId(new VariableMap(oidConfDef, defValue));
		} else if (oidConfDef.contains("ErrorCode")) {
			esaVariableBinding.setErrorCode(new VariableMap(oidConfDef, defValue));
		} else if (oidConfDef.contains("Severity")) {
			esaVariableBinding.setSeverity(new VariableMap(oidConfDef, defValue));
		} else if (oidConfDef.contains("OriginatingSource")) {
			esaVariableBinding.setOriginatingSource(new VariableMap(oidConfDef, defValue));
		} else if (oidConfDef.contains("sysUpTime")) {
			esaVariableBinding.setSysUpTime(new VariableMap(oidConfDef, defValue));
		}
	}
}
