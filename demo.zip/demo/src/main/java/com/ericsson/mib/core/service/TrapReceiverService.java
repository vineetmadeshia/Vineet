package com.ericsson.mib.core.service;

public interface TrapReceiverService {

	void startListener();

	void close();

}
