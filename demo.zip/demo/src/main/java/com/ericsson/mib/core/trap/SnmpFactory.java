package com.ericsson.mib.core.trap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.snmp4j.Snmp;

public class SnmpFactory {
	
	private static final Logger logger = LoggerFactory.getLogger(SnmpFactory.class);

	private static Snmp snmp;

	private SnmpFactory() {

	}

	public static Snmp getInstance() {
		if (snmp == null) {
			synchronized (Snmp.class) {
				if (snmp == null) {
					logger.info("SNMP instance creation initiated");
					snmp = new Snmp();
				}
			}
		}
		logger.info("SNMP instance created : {}",snmp);
		return snmp;
	}
}
