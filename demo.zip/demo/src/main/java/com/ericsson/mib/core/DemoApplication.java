package com.ericsson.mib.core;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.LoggerFactory;
import org.snmp4j.log.JavaLogFactory;
import org.snmp4j.log.LogFactory;
import org.snmp4j.log.LogLevel;
import org.snmp4j.smi.OID;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.ericsson.mib.core.common.util.DateUtil;

@SpringBootApplication
@EnableScheduling
public class DemoApplication {

	private static final org.slf4j.Logger logger = LoggerFactory.getLogger(DemoApplication.class);
	
	static {
		/*
		 * LogFactory.setLogFactory(new ConsoleLogFactory());
		 * ConsoleLogAdapter.setDebugEnabled(true);
		 */
	    
		LogFactory.setLogFactory(new JavaLogFactory());
	    // Optionally set log level on root logger:
	    LogFactory.getLogFactory().getRootLogger().setLogLevel(LogLevel.ALL);
	}

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(DemoApplication.class, args);
		DemoApplication app = ctx.getBean(DemoApplication.class);
		//app.readMpbn();
	}

	public void checkOid() {
		OID oid = new OID("1.3.6.1.2.1.4.31.1.1.11");
		// String substring = oid.toString().substring(0,
		// oid.toString().lastIndexOf("."));
		String subOidOption = oid.toString().substring(0, oid.toString().length() - 3);
		System.out.println("substring -->" + subOidOption);
	}

	public void readMpbn() {
		String regex = "show log";
		try {
			String content = new String(
					Files.readAllBytes(Paths.get("C:\\Users\\emadpun\\OneDrive - Ericsson\\Desktop\\mpbn_output.txt")));
			String[] endSplitContent = content.split(regex);
			String alarmText = endSplitContent[1].trim();
			String[] splitAlarm = alarmText.split("\r\n");
			for (String alrow : splitAlarm) {
				String[] alField = alrow.split("<|>");
				String eventTime = alField[0].split("\\.")[0];
				String alPart = alField[1];
				String[] alPartSplit = alPart.split(":");
				String severity= alPartSplit[0];
				String specificProb = alPartSplit[1];
				String additionalText = alField[2];
				System.out.println("alarms");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void readNcli() {
		try {
			String endRegex = "END";
			String regex = "ALARM DATA";
			String content = new String(
					Files.readAllBytes(Paths.get("C:\\Users\\emadpun\\OneDrive - Ericsson\\Desktop\\ncli_output.txt")));
			String[] endSplitContent = content.split(endRegex);
			String[] outputArr = endSplitContent[0].split(regex);
			for (int i = 0; i < outputArr.length; i++) {
				if (i > 0) {
					Map<String, String> alarmMap = new HashMap<>();
					String[] alarmContent = outputArr[i].trim().split("\r\n");
					for (int j = 0; j < alarmContent.length; j++) {
						String[] keyValue = alarmContent[j].split("\s+=\s+");
						if (keyValue.length > 1) {
							alarmMap.put(keyValue[0], keyValue[1]);
						}
					}
					System.out.println("alarms :" + alarmMap.size());
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void readAllip() {
		try {
			String regex = "..\\/....";
			String content = new String(Files
					.readAllBytes(Paths.get("C:\\Users\\emadpun\\OneDrive - Ericsson\\Desktop\\allip_output.txt")));
			List<String> patterns = getGroupsByPattern(content, regex);
			String[] outputArr = content.split(regex);
			for (int i = 0; i < outputArr.length; i++) {
				if (i > 0) {
					String severity = patterns.get(i - 1);
					String alarmSect = outputArr[i];
					String[] alarmDetails = alarmSect.split("\r\n");
					String alrmFirstLine = alarmDetails[0].trim();
					String alrmTitle = alarmDetails[1].trim();
					String[] alrmPart = alrmFirstLine.split("\s+");
					String eventTime = alrmPart[3] + " " + alrmPart[4] + "00";
					Date date = DateUtil.getDate(eventTime, "yyMMdd HHmmss");
					String alarmId = alrmPart[2];
					String alarmDesc = "";
					for (int j = 2; j < alarmDetails.length; j++) {
						alarmDesc = alarmDesc + alarmDetails[j] + "\n";
					}
					System.out.println(
							" ------>severity :" + severity + " ------>alrmTitle :" + alrmTitle + " ------>eventTime :"
									+ eventTime + " ------>alarmId :" + alarmId + " ------>alarmDesc :" + alarmDesc);
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static List<String> getGroupsByPattern(String output, String pattern) {
		List<String> matches = new ArrayList<String>();
		Matcher matcher = getMatcher(output, pattern, Pattern.MULTILINE);
		while (matcher.find()) {
			matches.add(matcher.group());
		}
		return matches;
	}

	public static Matcher getMatcher(String output, String pattern, int flags) {
		final Pattern regexPattern = Pattern.compile(pattern, flags);
		final Matcher matcher = regexPattern.matcher(output);
		return matcher;
	}

}
