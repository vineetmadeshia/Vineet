package com.ericsson.mib.core.common.constants;

public final class MibConstants {
  public static final String MODULE_IDENTITY = "MODULE-IDENTITY";
  
  public static final String MODULE_COMPLIANCE = "MODULE-COMPLIANCE";
  
  public static final String OBJECT_TYPE = "OBJECT-TYPE";
  
  public static final String NOTIFICATION_TYPE = "NOTIFICATION-TYPE";
  
  public static final String NOTIFICATION_GROUP = "NOTIFICATION-GROUP";
  
  public static final String OBJECT_GROUP = "OBJECT-GROUP";
  
  public static final String OBJECT_IDENTIFIER = "OBJECT IDENTIFIER";
  
  public static final String OBJECT_IDENTIFIER_ = "OBJECT_IDENTIFIER";
  
  public static final String OBJECT_IDENTITY = "OBJECT-IDENTITY";
  
  public static final String SPLIT_BY_IDENTIFIERS = "MODULE-IDENTITY|OBJECT-TYPE|NOTIFICATION-TYPE|NOTIFICATION-GROUP|OBJECT-GROUP|OBJECT_IDENTIFIER|OBJECT-IDENTITY|MODULE-COMPLIANCE|OBJECT IDENTIFIER";
  
  public static final String OID_SPLITTER = "::=(\\s+|)\\{";
  
  public static final String MIB_SPLITTER = "\\}.*\r\n|\\}.*\t|\\}.*\n";
}
