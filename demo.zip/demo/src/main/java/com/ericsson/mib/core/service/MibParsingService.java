package com.ericsson.mib.core.service;

public interface MibParsingService {
	  void loadMibs(String paramString);
	}
