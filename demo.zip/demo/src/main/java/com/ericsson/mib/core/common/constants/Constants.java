package com.ericsson.mib.core.common.constants;

public final class Constants {
  public static final String EMPTY = "";
  
  public static String DECIMAL_FORMAT = "#.####";
  
  public static final String EQUALS = "1";
  
  public static final String NOT_EQUALS = "2";
  
  public static final String CONTAINS = "3";
  
  public static final String DOESNT_CONTAIN = "4";
  
  public static final String STARTS_WITH = "5";
  
  public static final String ENDS_WITH = "6";
  
  public static final String LIKE = "7";
  
  public static final String IS_EMPTY = "8";
  
  public static final String IS_NOT_EMPTY = "9";
  
  public static final String IN = "10";
  
  public static final String NOT_IN = "11";
  
  public static final String EQUALS_TEXT = "eq";
  
  public static final String NOT_EQUALS_TEXT = "neq";
  
  public static final String IN_TEXT = "in";
  
  public static final String NOT_IN_TEXT = "notin";
  
  public static final String NUMBER_EQUALS = "1";
  
  public static final String NUMBER_NOT_EQUALS = "2";
  
  public static final String LESS_THAN = "3";
  
  public static final String GREATER_THAN = "4";
  
  public static final String LESS_THAN_OR_EQUALS = "5";
  
  public static final String GREATER_THAN_OR_EQUALS = "6";
  
  public static final String DATE_EQUALS = "1";
  
  public static final String DATE_LESS_THAN = "2";
  
  public static final String DATE_GREATER_THAN = "3";
  
  public static final String NUMBER_EQUALS_TEXT = "eq";
  
  public static final String NUMBER_NOT_EQUALS_TEXT = "neq";
  
  public static final String LESS_THAN_TEXT = "lt";
  
  public static final String GREATER_THAN_TEXT = "gt";
  
  public static final String LESS_THAN_OR_EQUALS_TEXT = "lt&eq";
  
  public static final String GREATER_THAN_OR_EQUALS_TEXT = "gt&eq";
}
