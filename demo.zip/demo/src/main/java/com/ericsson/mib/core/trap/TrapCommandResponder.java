package com.ericsson.mib.core.trap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.snmp4j.CommandResponder;
import org.snmp4j.CommandResponderEvent;
import org.snmp4j.PDU;
import org.snmp4j.smi.Address;
import org.springframework.stereotype.Component;

@Component
public class TrapCommandResponder implements CommandResponder {

	private static final Logger logger = LoggerFactory.getLogger("traps");
	/**
	 * This method will be called whenever a pdu is received on the given port
	 * specified in the listen() method
	 */

	public synchronized void processPdu(CommandResponderEvent cmdRespEvent) {
		try {
			PDU pdu = cmdRespEvent.getPDU();
			Address peerAddress = cmdRespEvent.getPeerAddress();
			String ip = TrapProcessor.getPeerAddress(peerAddress.toString());

			logger.info("Received trap for node :: " + peerAddress + " || PDU :: "
					+ pdu);
		}catch(Exception e) {
			logger.error("error in process pdu : {} ",e);
		}
	}
}
