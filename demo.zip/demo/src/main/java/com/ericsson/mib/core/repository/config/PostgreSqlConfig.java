package com.ericsson.mib.core.repository.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource({"classpath:repository/config/postgresql.properties"})
public class PostgreSqlConfig {}
