package com.ericsson.mib.core.trap.dto;

public class VariableMap {
  private String variableKey;
  
  private String variableValue;
  
  public VariableMap(String variableKey, String variableValue) {
    this.variableKey = variableKey;
    this.variableValue = variableValue;
  }
  
  public String getVariableKey() {
    return this.variableKey;
  }
  
  public void setVariableKey(String variableKey) {
    this.variableKey = variableKey;
  }
  
  public String getVariableValue() {
    return this.variableValue;
  }
  
  public void setVariableValue(String variableValue) {
    this.variableValue = variableValue;
  }
}
