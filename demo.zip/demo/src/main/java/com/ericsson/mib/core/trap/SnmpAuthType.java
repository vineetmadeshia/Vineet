package com.ericsson.mib.core.trap;

import org.snmp4j.smi.OID;

public enum SnmpAuthType {
	AuthMD5("AuthMD5") {
		@Override
		public OID getOID() {
			return org.snmp4j.security.AuthMD5.ID;
		}
	},
	AuthHMAC128SHA224("AuthHMAC128SHA224") {
		@Override
		public OID getOID() {
			return org.snmp4j.security.AuthHMAC128SHA224.ID;
		}
	},
	AuthHMAC192SHA256("AuthHMAC192SHA256") {
		@Override
		public OID getOID() {
			return org.snmp4j.security.AuthHMAC192SHA256.ID;
		}
	},
	AuthHMAC256SHA384("AuthHMAC256SHA384") {
		@Override
		public OID getOID() {
			return org.snmp4j.security.AuthHMAC256SHA384.ID;
		}
	},
	AuthHMAC384SHA512("AuthHMAC384SHA512") {
		@Override
		public OID getOID() {
			return org.snmp4j.security.AuthHMAC384SHA512.ID;
		}
	},
	AuthSHA("AuthSHA") {
		@Override
		public OID getOID() {
			return org.snmp4j.security.AuthSHA.ID;
		}
	};
	
	String type;
	
	private SnmpAuthType(String type){
		this.type = type; 
	}
	
	public abstract OID getOID();
}
